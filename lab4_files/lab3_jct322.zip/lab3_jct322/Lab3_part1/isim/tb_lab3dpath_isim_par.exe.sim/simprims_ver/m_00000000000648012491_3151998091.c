/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000000648012491_3151998091_3376525849_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3376525849", "isim/tb_lab3dpath_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3376525849.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4171868292_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4171868292", "isim/tb_lab3dpath_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4171868292.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1490369352_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1490369352", "isim/tb_lab3dpath_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1490369352.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2391595093_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2391595093", "isim/tb_lab3dpath_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2391595093.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3728820710_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3728820710", "isim/tb_lab3dpath_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3728820710.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3028728101_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3028728101", "isim/tb_lab3dpath_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3028728101.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2145020544_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2145020544", "isim/tb_lab3dpath_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2145020544.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3292315892_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3292315892", "isim/tb_lab3dpath_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3292315892.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1336549697_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1336549697", "isim/tb_lab3dpath_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1336549697.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2314494463_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2314494463", "isim/tb_lab3dpath_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2314494463.didat");
}
